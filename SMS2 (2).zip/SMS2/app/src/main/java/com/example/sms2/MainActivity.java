package com.example.sms2;

import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private EditText editTextRecipient, editTextMessage;
    private LinearLayout layoutRecipientList;
    private List<String> recipients;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextRecipient = findViewById(R.id.editTextRecipient);
        editTextMessage = findViewById(R.id.editTextMessage);
        layoutRecipientList = findViewById(R.id.layoutRecipientList);
        Button buttonAddRecipient = findViewById(R.id.buttonAddRecipient);
        Button buttonSend = findViewById(R.id.buttonSend);

        recipients = new ArrayList<>();

        buttonAddRecipient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String recipient = editTextRecipient.getText().toString().trim();
                if (!recipient.isEmpty()) {
                    addRecipient(recipient);
                    editTextRecipient.setText("");
                }
            }
        });

        buttonSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message = editTextMessage.getText().toString().trim();
                if (!message.isEmpty() && !recipients.isEmpty()) {
                    sendMessage(message);
                } else {
                    Toast.makeText(MainActivity.this, "Please enter message and recipient", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void addRecipient(String recipient) {
        recipients.add(recipient);
        EditText editText = new EditText(this);
        editText.setText(recipient);
        layoutRecipientList.addView(editText);
    }

    private void sendMessage(String message) {
        SmsManager smsManager = SmsManager.getDefault();
        for (String recipient : recipients) {
            smsManager.sendTextMessage(recipient, null, message, null, null);
        }
        Toast.makeText(this, "Message sent to all recipients", Toast.LENGTH_SHORT).show();
    }
}
