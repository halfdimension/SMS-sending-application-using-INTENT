package com.example.sms3;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ContactListActivity extends AppCompatActivity implements ContactAdapter.OnItemClickListener {

    private List<Contact> contactList;
    private RecyclerView recyclerView; // Corrected variable name
    private ContactAdapter contactAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_list);

        // Initialize contact list
        contactList = new ArrayList<>();
        contactList.add(new Contact("Daksh", "9305553669"));
        contactList.add(new Contact("Shanky Shashank", "8174996694"));
        contactList.add(new Contact("Harsh", "9518686944"));
        contactList.add(new Contact("Akriti", "8219745214"));
        contactList.add(new Contact("Ayush OP", "7303020157"));
        contactList.add(new Contact("Yuvraj Singh", "8770846365"));
        contactList.add(new Contact("Anuj Munjal", "8708487524"));


        // Add more contacts as needed

        // Initialize RecyclerView
        recyclerView = findViewById(R.id.recyclerView); // Corrected ID
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        contactAdapter = new ContactAdapter(this, contactList, this);
        recyclerView.setAdapter(contactAdapter);
    }

    @Override
    public void onItemClick(Contact contact) {
        // Handle click on contact item
        Intent intent = new Intent();
        intent.putExtra("contactName", contact.getName());
        intent.putExtra("contactPhoneNumber", contact.getPhoneNumber()); // Make sure this matches the key used in MainActivity
        setResult(RESULT_OK, intent);
        finish();
    }


}
