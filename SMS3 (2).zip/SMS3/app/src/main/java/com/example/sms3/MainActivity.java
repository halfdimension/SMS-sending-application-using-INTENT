package com.example.sms3;

import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private EditText editTextRecipient, editTextMessage;
    private LinearLayout layoutRecipientList;
    private List<Contact> recipients;
    private static final int REQUEST_CONTACT = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextRecipient = findViewById(R.id.editTextRecipient);
        editTextMessage = findViewById(R.id.editTextMessage);
        layoutRecipientList = findViewById(R.id.layoutRecipientList);
        Button buttonAddRecipient = findViewById(R.id.buttonAddRecipient);
        Button buttonSend = findViewById(R.id.buttonSend);
        ImageView bottomImage = findViewById(R.id.bottomImage); // Added ImageView reference

        // Load the animation
        Animation animation = AnimationUtils.loadAnimation(this, R.anim.slide_in_from_left);

        // Apply the animation to the ImageView
        bottomImage.startAnimation(animation);

        recipients = new ArrayList<>();

        editTextRecipient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start ContactListActivity to select a contact
                Intent intent = new Intent(MainActivity.this, ContactListActivity.class);
                startActivityForResult(intent, REQUEST_CONTACT);
            }
        });

        buttonAddRecipient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String recipientName = editTextRecipient.getText().toString().trim();
                if (!recipientName.isEmpty()) {
                    // Create a Contact object with the name
                    Contact contact = new Contact(recipientName, ""); // Provide an empty phone number
                    addRecipient(contact);
                    editTextRecipient.setText("");
                }
            }
        });

        buttonSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message = editTextMessage.getText().toString().trim();
                if (!message.isEmpty() && !recipients.isEmpty()) {
                    sendMessage(message);
                } else {
                    Toast.makeText(MainActivity.this, "Please enter message and recipient", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void addRecipient(Contact contact) {
        recipients.add(contact);
        EditText editText = new EditText(this);
        editText.setText(contact.getName());
        layoutRecipientList.addView(editText);
    }

    private void sendMessage(String message) {
        SmsManager smsManager = SmsManager.getDefault();
        for (Contact recipient : recipients) {
            String phoneNumber = recipient.getPhoneNumber();
            if (isValidPhoneNumber(phoneNumber)) {
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            } else {
                Log.d("PhoneNumberDebug", "Invalid phone number: " + phoneNumber); // Log invalid phone number
                Toast.makeText(this, "Invalid phone number: " + phoneNumber, Toast.LENGTH_SHORT).show();
            }
        }
        Toast.makeText(this, "Message sent to all recipients", Toast.LENGTH_SHORT).show();
    }

    private boolean isValidPhoneNumber(String phoneNumber) {
        // Check if phone number is not empty and contains only digits
        if (phoneNumber.matches("[0-9]+")) {
            // Check if phone number length is within a valid range
            int length = phoneNumber.length();
            return length >= 7 && length <= 15; // Example: US phone numbers are between 7 and 15 digits
        } else {
            return false;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CONTACT && resultCode == RESULT_OK && data != null) {
            // Get selected contact data from ContactListActivity
            String contactName = data.getStringExtra("contactName");
            String contactNumber = data.getStringExtra("contactPhoneNumber"); // Ensure this matches the key used in ContactListActivity
            Log.d("ContactInfo", "Contact Name: " + contactName);
            Log.d("ContactInfo", "Contact Number: " + contactNumber);
            // Set the selected contact name as the recipient
            editTextRecipient.setText(contactName);
            // Create a Contact object with the name and number
            Contact contact = new Contact(contactName, contactNumber);
            addRecipient(contact);
        }
    }
}
